scores = {

    "sem_bic_score": {
        "data_type": ["continuous"],
        "penalty_discount": [1],
        "structure_prior": [1]
    },

    "bdeu": {
        "data_type": ["categorical"],
        "penalty_discount": [1],
        "structure_prior": [1]
    },

    "cg_bic": {
        "data_type": ["mixed"],
        "penalty_discount": [1],
        "structure_prior": [1]
    },

    "dg_bic": {
        "data_type": ["mixed"],
        "penalty_discount": [1],
        "structure_prior": [1]
    }

}