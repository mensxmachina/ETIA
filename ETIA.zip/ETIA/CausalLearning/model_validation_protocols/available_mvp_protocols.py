
from .kfold.kfold import KFoldCV

available_mvp_protocols = {
    "KFoldCV": KFoldCV(),
}


