from setuptools import setup, find_packages

setup(
    name='ETIA',
    version='0.1',
    packages=find_packages(include=['ETIA', 'ETIA.*']),
    include_package_data=True,
    package_data={
        'ETIA.AFS.feature_selectors': ['fbed_with_idx.R', 'ses_with_idx.R'],
        'ETIA.CausalLearning.algorithms.jar_files': ['colt.jar', 'commons-collections4-4.1.jar', 'commons-collections4-4.4.jar', 'commons-math3-3.6.1.jar', 'data-reader-7.1.2-2.jar', 'data-reader-7.2.0.jar', 'jsoup-1.15.2.jar', 'tetradlib.jar', 'xom-1.3.7.jar']
    },
    install_requires=[
        # List your dependencies here
    ],
)
